/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AnnouncementBar } from "./components/AnnouncementBar";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { ProductList } from "./components/ProductList";
import { Story } from "./components/Story";
import { Testimonials } from "./components/Testimonials";
import { Gallery } from "./components/Gallery";
import { Values } from "./components/Values";
import { Faq } from "./components/Faq";
import { FinalCta, Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <AnnouncementBar />
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <ProductList />
        <Story />
        <Testimonials />
        <Gallery />
        <Values />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
    </div>
  );
}

