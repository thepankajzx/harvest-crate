import { ShoppingBag, Menu } from "lucide-react";

export function Navbar() {
  return (
    <nav className="sticky top-0 z-50 bg-brand-light/90 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          
          <div className="flex md:hidden">
            <button className="p-2 text-stone-600 hover:text-brand-dark transition-colors">
              <Menu size={24} />
            </button>
          </div>
          
          <div className="flex-shrink-0 flex items-center justify-center flex-1 md:flex-none">
            <a href="/" className="font-serif text-2xl font-bold tracking-tight text-brand-dark">
              Harvest Crate
            </a>
          </div>

          <div className="hidden md:flex flex-1 justify-center space-x-8">
            {['Home', 'Shop Apples', 'Our Story', 'Rent A Tree', 'Journey'].map((item) => (
              <a 
                key={item} 
                href="#" 
                className="text-stone-600 hover:text-brand-green font-medium text-sm uppercase tracking-wider transition-colors"
              >
                {item}
              </a>
            ))}
          </div>

          <div className="flex items-center space-x-4">
            <button className="relative p-2 text-stone-600 hover:text-brand-dark transition-colors group">
              <ShoppingBag size={24} className="group-hover:scale-105 transition-transform" />
              <span className="absolute top-0 right-0 inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold leading-none text-white transform translate-x-1/4 -translate-y-1/4 bg-brand-green rounded-full">
                0
              </span>
            </button>
          </div>
          
        </div>
      </div>
    </nav>
  );
}
