import { ArrowRight, ShieldCheck, Truck, Leaf } from "lucide-react";

export function Hero() {
  return (
    <div className="relative bg-stone-900 overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1590847953251-512c4ce0ea1e?auto=format&fit=crop&q=80&w=2000"
          alt="Orchard background"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-stone-900/40 to-transparent" />
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-24 flex flex-col items-center text-center">
        <span className="inline-flex items-center space-x-2 bg-brand-green/90 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-8 shadow-sm">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          <span>Now Harvesting</span>
        </span>
        
        <h1 className="text-4xl sm:text-5xl md:text-7xl font-serif text-white max-w-4xl leading-tight mb-6">
          This Season's Harvest <br />
          <span className="text-stone-300 italic font-light">Fresh From the Orchard</span>
        </h1>
        
        <p className="text-lg text-stone-300 max-w-2xl mb-10 font-medium">
          Crisp, juicy apples straight from the hills to your door. Hand-picked, naturally grown, and packed with love.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 mb-16">
          <a href="#products" className="inline-flex items-center justify-center px-8 py-4 text-base font-bold text-brand-dark bg-white rounded-full hover:bg-stone-100 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
            Order Your Box
            <ArrowRight className="ml-2" size={18} />
          </a>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-12 text-stone-200 border-t border-white/10 pt-8 w-full max-w-3xl">
          <div className="flex flex-col items-center gap-2">
            <ShieldCheck className="text-brand-green" size={28} />
            <span className="text-sm font-semibold tracking-wide uppercase">Secure Checkout</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <Truck className="text-brand-green" size={28} />
            <span className="text-sm font-semibold tracking-wide uppercase">Free Delivery</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <Leaf className="text-brand-green" size={28} />
            <span className="text-sm font-semibold tracking-wide uppercase">Freshness Guaranteed</span>
          </div>
        </div>
      </div>
    </div>
  );
}
