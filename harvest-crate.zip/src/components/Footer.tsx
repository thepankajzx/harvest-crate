export function FinalCta() {
  return (
    <section className="py-24 bg-brand-dark text-white text-center px-4">
      <div className="max-w-3xl mx-auto">
        <span className="text-brand-green font-bold tracking-widest uppercase mb-6 block text-sm">2026 Harvest · Limited Stock Remaining</span>
        <h2 className="text-4xl sm:text-6xl font-serif font-bold mb-8 leading-tight">
          Taste the difference <br />
          <span className="text-stone-400 italic font-light">before the season ends.</span>
        </h2>
        <p className="text-xl text-stone-300 font-medium mb-12 max-w-2xl mx-auto leading-relaxed">
          Once this harvest is gone, the next batch comes only next year. These aren't supermarket apples — they were on a tree this week.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="bg-brand-green text-white font-bold py-4 px-10 rounded-full hover:bg-emerald-700 transition-colors shadow-lg">
            Order Your Box Now
          </button>
          <button className="bg-white/10 text-white font-bold py-4 px-10 rounded-full hover:bg-white/20 transition-colors">
            Bulk / Gift Orders
          </button>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-stone-900 text-stone-400 py-16 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-3xl font-serif text-white font-bold mb-6">Harvest Crate</h3>
            <p className="font-medium leading-relaxed max-w-md">
              At Harvest Crate, we specialize in delivering fresh, high-quality apples directly from our farms nestled in the picturesque hills. No wax, no cold storage, just nature's best.
            </p>
          </div>
          <div>
            <h4 className="text-white font-bold tracking-wider uppercase mb-6 text-sm">Explore</h4>
            <ul className="space-y-4 font-medium">
              <li><a href="#" className="hover:text-brand-green transition-colors">Home</a></li>
              <li><a href="#products" className="hover:text-brand-green transition-colors">Shop Apples</a></li>
              <li><a href="#" className="hover:text-brand-green transition-colors">Our Story</a></li>
              <li><a href="#" className="hover:text-brand-green transition-colors">Rent A Tree</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold tracking-wider uppercase mb-6 text-sm">Contact & Support</h4>
            <ul className="space-y-4 font-medium">
              <li><a href="#" className="hover:text-brand-green transition-colors">FAQ</a></li>
              <li><a href="#" className="hover:text-brand-green transition-colors">Refund Policy</a></li>
              <li><a href="#" className="hover:text-brand-green transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-brand-green transition-colors">Contact Us</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm font-medium">
          <p>Copyright © 2026 Harvest Crate. All rights reserved.</p>
          <p className="flex items-center">Made with <span className="text-rose-500 mx-1">♥</span> for farming families</p>
        </div>
      </div>
    </footer>
  );
}
