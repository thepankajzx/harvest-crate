export const products = [
  {
    id: "p1",
    title: "Heritage Red Delicious",
    subtitle: "Sweet & Crisp",
    description: "Deep red, crisp, naturally sweet. The apple most families reorder every season.",
    badge: "Best Seller",
    rating: 5,
    reviews: 140,
    price: {
      "5 Kg": 1499,
      "10 Kg": 2799
    },
    originalPrice: {
      "5 Kg": 1650,
      "10 Kg": 3300
    },
    image: "https://images.unsplash.com/photo-1560806887-1e4cd0b6fac6?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "p2",
    title: "Golden Orchard Apples",
    subtitle: "Honey-sweet & Buttery-soft",
    description: "Honey-sweet, buttery-soft. Gentle for kids & elders, rich in Vitamin C.",
    badge: "Best Seller",
    rating: 5,
    reviews: 67,
    price: {
      "5 Kg": 1499,
      "10 Kg": 2799
    },
    originalPrice: {
      "5 Kg": 1999,
      "10 Kg": 3998
    },
    image: "https://images.unsplash.com/photo-1611574474484-dedf88067cea?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "p3",
    title: "Mountain Fuji Apples",
    subtitle: "Sweetest & Juiciest",
    description: "The sweetest apple on our hillsides — dense, exceptionally juicy and crisp enough to hear.",
    badge: "Sweetest",
    rating: 5,
    reviews: 29,
    price: {
      "5 Kg": 1899,
      "10 Kg": 3599
    },
    originalPrice: {
      "5 Kg": 2150,
      "10 Kg": 4300
    },
    image: "https://images.unsplash.com/photo-1570145820259-b5b80c5c8bd6?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "p4",
    title: "Tart Granny Smith",
    subtitle: "Tangy & Firm",
    description: "Bold, tart & crisp. Low sugar, diabetic-friendly, perfect for baking.",
    badge: "Lower in Sugar",
    rating: 5,
    reviews: 38,
    price: {
      "5 Kg": 1799,
      "10 Kg": 3399
    },
    originalPrice: {
      "5 Kg": 2000,
      "10 Kg": 4000
    },
    image: "https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?auto=format&fit=crop&q=80&w=800",
  }
];
